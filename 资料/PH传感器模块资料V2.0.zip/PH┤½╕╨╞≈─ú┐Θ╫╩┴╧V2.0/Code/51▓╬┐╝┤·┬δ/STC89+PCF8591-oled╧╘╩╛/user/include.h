#ifndef __INCLUDE_H
#define	__INCLUDE_H

//#define uchar  unsigned char
//#define uint unsigned int
#include <stdio.h>
#include <intrins.h>
#include "math.h"
#include "I2C.h"
#include "PCF8591.h"
//#include "lcd.h"
#include "oled.h"


#endif /* __INCLUDE_H */